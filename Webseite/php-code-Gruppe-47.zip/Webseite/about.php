<!doctype html>
<html lang="de">
    <?php include 'head.php' ?>
	<body >
        <?php include 'header.php' ?>
<div class="container" id="about">
			<h1>Über uns</h1>
			<p>
				Wir sind Studenten der TH-Köln am Campus Gummersbach. Diese Website ist im Rahmen eines Datenbanken Projektes
				entstanden.
			</p>
		</div>
        <?php include 'footer.php' ?>
	</body>
</html>