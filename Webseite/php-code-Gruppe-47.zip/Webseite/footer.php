<!--
	footer mit class bg-dark text-center text-white fixed-bottom
		div mit class text-center p-3 mit style background-color rgba(0,0,0,0.2)
			a mit class text-white
-->
<footer class="bg-dark text-center text-white fixed-bottom">
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
        © 2022 Copyright:
        <a class="text-white" href="index.php">buecherwurm.de</a>
    </div>
</footer>